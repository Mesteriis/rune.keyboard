package io.github.mesteriis.rune.keyboard.smarttyping.lexicon
import io.github.mesteriis.rune.keyboard.ime.model.KeyboardLanguage
internal object ProbeRadixIdentities {
    val assets = mapOf(
        KeyboardLanguage.ENGLISH to PackedAsset("en.radix", 3103867L, "40c55b90faedc1613433b8bb73749a2279e1bd5ebe0bcadc7b53e43d9fe10502"),
        KeyboardLanguage.SPANISH to PackedAsset("es.radix", 16148361L, "7faa4b20639f137394430893a25efb7b4fc25bdb0cdd04018f64d64dd271e736"),
        KeyboardLanguage.RUSSIAN to PackedAsset("ru.radix", 38467914L, "f8b9b2990b856e3acb802bbe176d14818c0af14dc4b284cb70d2d369d8a4eb8b"),
    )
}
